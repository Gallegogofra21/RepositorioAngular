import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-personaje-item',
  templateUrl: './personaje-item.component.html',
  styleUrls: ['./personaje-item.component.css']
})
export class PersonajeItemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
