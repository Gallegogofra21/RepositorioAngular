import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.css']
})
export class FormsComponent implements OnInit {
  model = new Usuario('', '');
  submitted = false;

  constructor() {}

  ngOnInit(): void {}

  onSubmit() { this.submitted = true; }

}

export class Usuario {
  constructor(
    public email: String,
    public password: String
  ){}
}


