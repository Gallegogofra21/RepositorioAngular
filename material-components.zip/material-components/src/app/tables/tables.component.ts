import {Component} from '@angular/core';

export interface TablaAlumnos {
  Nombre: string;
  Apellidos: string;
  Edad: number;
  Curso: string;
}

const ELEMENT_DATA: TablaAlumnos[] = [
  {Nombre: 'Guillermo', Apellidos: 'Hydrogen', Edad: 15, Curso: '2º DAM'},
  {Nombre: 'Jesús', Apellidos: 'Helium', Edad: 20, Curso: '2º DAM'},
  {Nombre: 'Francisco', Apellidos: 'Lithium', Edad: 19, Curso: '2º DAM'},
  {Nombre: 'Juan Carlos', Apellidos: 'Beryllium', Edad: 19, Curso: '2º DAM'},
  {Nombre: 'Alfonso', Apellidos: 'Boron', Edad: 21, Curso: '2º DAM'},
  {Nombre: 'Moisés', Apellidos: 'Carbon', Edad: 20, Curso: '2º DAM'},
  {Nombre: 'Sergio', Apellidos: 'Nitrogen', Edad: 23, Curso: '2º DAM'},
  {Nombre: 'Antonio', Apellidos: 'Oxygen', Edad: 22, Curso: '2º DAM'},
  {Nombre: 'Daniel', Apellidos: 'Fluorine', Edad: 19, Curso: '2º DAM'},
  {Nombre: 'Jaime', Apellidos: 'Neon', Edad: 20, Curso: '2º DAM'},
];

@Component({
  selector: 'app-tables',
  templateUrl: './tables.component.html',
  styleUrls: ['./tables.component.css']
})
export class TablesComponent {
  displayedOriginalColumns: string[] = ['Nombre', 'Apellidos', 'Edad', 'Curso', 'Editar', 'Borrar'];
  displayedColumns: string[] = ['Nombre', 'Apellidos', 'Edad', 'Curso', 'Editar', 'Borrar'];
  dataSource = ELEMENT_DATA;

  checkboxChange(isChecked: boolean, columName: string) {
      if(isChecked){
        this.displayedColumns.splice(this.displayedOriginalColumns.indexOf(columName), 0, columName);
      }else{
        let originalIndex = this.displayedColumns.indexOf(columName);
       // let indexToAdd = originalIndex > this.displayedColumns.length?
        this.displayedColumns.splice(this.displayedColumns.indexOf(columName), 1);
      }
  }
}

