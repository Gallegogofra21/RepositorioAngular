export const environment = {
  production: true,
  apiBaseUrl: 'https://www.minitwitter.com:3001/apiv1'
};
